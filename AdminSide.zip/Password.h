// Version 0.1 wh and dp and zs
// Password.h
// CIT237-01 - Bakery Group Project  - Password
// Used to validate password
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017



#pragma once
#ifndef PASSWORD_H
#define PASSWORD_H


#include <fstream>

#include <iostream>
#include <string>
#include <cstring>
using namespace std;



class Password {
private:
	string userName;
	string password;


	bool passwordhandler(string pass);
	bool testfordigit(char * ptr, int size);
	bool testforcharacter(char * ptr, int size);
	bool testforuppercase(char * ptr, int size);
	bool checkrange(string x);
	void passwordrequirements();
	bool finalcheck(char * ptr, int size);
	bool testforlowercase(char * ptr, int size);

	int LoginCheck(string user, string pass);
	void Register();
	

public:
	bool getpassword(string password);
	bool userLogin();
};



#endif
