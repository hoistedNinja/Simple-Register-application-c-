// Version 0.2 dp
// Version 0.1 wh and dp and zs
// Password.cpp
// CIT237-01 - Bakery Group Project  - Password
// Used to validate password
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/11/2017

#include "Password.h"

bool Password::passwordhandler(string pass) {//getting password and converting to character ptr array, if all of the functions return true, return true to main and accept password
	char * ptr = new char[pass.length()];
	if (checkrange(pass)) {
		for (int i = 0; i < pass.length(); i++) {
			ptr[i] = pass.at(i);
		}
		bool a = testfordigit(ptr, pass.length());
		bool b = testforcharacter(ptr, pass.length());
		bool c = testforuppercase(ptr, pass.length());
		bool d = finalcheck(ptr, pass.length());
		bool z = testforlowercase(ptr, pass.length());
		if (a&&b&&c&&d&&z)
			return true;
		else
			return false;
	}
	else {
		return false;
	}
}

bool Password::testfordigit(char * ptr, int size) {// checking for digit with isdigit function
	int count = 0;
	for (int i = 0; i < size; i++) {
		if (isdigit(ptr[i]))
			++count;
	}
	if (count > 0)
		return true;
	else
		return false;
}

bool Password::testforuppercase(char * ptr, int size) {//checking for uppercase with the isupper function
	int count = 0;
	char charelement;
	for (int i = 0; i < size; i++) {
		charelement = ptr[i];
		if (isupper(charelement))
			++count;
	}
	if (count > 0)
		return true;
	else
		return false;
}

bool Password::testforlowercase(char * ptr, int size) {//checking for uppercase with the isupper function
	int count = 0;
	char charelement;
	for (int i = 0; i < size; i++) {
		charelement = ptr[i];
		if (islower(charelement))
			++count;
	}
	if (count > 0)
		return true;
	else
		return false;
}

bool Password::testforcharacter(char * ptr, int size) {// comparing each element in the password entered to the array of allowable characters with a nested for loop
	int count = 0;
	char stringofchars[5] = { '!','@','#','$','%' };
	for (int k = 0; k < size; k++) {
		for (int i = 0; i < 5; i++) {
			if (ptr[k] == stringofchars[i])
				++count;
		}
	}
	if (count > 0)
		return true;
	else
		return false;
}

bool Password::checkrange(string x) {                     //check if the length is correct
	if (x.length() > 15 || x.length() < 7)
		return false;
}

bool Password::getpassword(string password) {                              //get and return a correct password to main
	string getpassword;
	
	//StartPassword();
	getpassword = password;
	//passwordrequirements();
	//getline(cin, getpassword);  	// take in the password zs code

	cout << "TEST just read in password : " << password << endl;


	bool passwordverifier = passwordhandler(getpassword);
	return passwordverifier;
}

void Password::passwordrequirements() {
	cout << endl;
	cout << "Password must meet the following criteria: " << endl;
	cout << "    Length must have at least 7 and no more than 15 characters" << endl;
	cout << "    At least one lowercase letter" << endl;
	cout << "    At least one uppercase letter" << endl;
	cout << "    At least one number" << endl;
	cout << "    At least one of the following special characters: " << endl;
	cout << "	 '!','@','#','$','%' " << endl;
	cout << "    No space or other special characters. " << endl;
	cout << "\nEnter password:\t";
}

bool Password::finalcheck(char * ptr, int size) {//added in this function to make sure there are no characters that are not allowed
	bool check = true;
	for (int k = 0; k < size; k++) {//check every value in ptr
		if (!isalpha(ptr[k]) && !isdigit(ptr[k])) {// if the value in ptr is not a digit or letter, execute block
			if (ptr[k] != '!' && ptr[k] != '@' && ptr[k] != '#' && ptr[k] != '$' && ptr[k] != '%') { //if ptr is not equivalant to the allowed characters, check is set to false
				check = false;
				break;
			}
			else if (ptr[k] == '!' && '@' && '#' && '$' && '%')
				continue;
		}
	}
	return check;
}



// ****************************************************************************
// Function LoginCheck
//
// ***************************************************************************
int Password::LoginCheck(string user, string pass)
{
	ifstream file;
	string username, password;
	Password record;

	int n = 0;
	file.open("users.dat", ios::in | ios::binary);
	if (file.is_open())
	{
		while (!file.eof())
		{
			file >> username >> password;   // need to fix for binary
			//file.read(reinterpret_cast<char *>(&record), sizeof(record));
			n++;
			if (user == username && pass == password)
				return n;
		}
	}
	else
	{
		cout << "file not open" << endl;
	}
	return 0;
}



// *************************************************************************
// Function Register
//
// **************************************************************************
void Password::Register()
{
	string user;
	string pass;
	ifstream file;
	ofstream newuser;
	string username, password, passwordconfirm;
	file.open("users.dat", ios::app | ios::binary);
	newuser.open("users.dat", ios::app | ios::binary);
	bool uservalid = false;
	while (!uservalid)
	{
		cout << "Enter your username: ";
		cin >> username;
		cin.ignore(256, '\n');

		cout << endl;
		cout << "TEST need to validate uesrname not already used." << endl;
		cout << endl;
		passwordrequirements();
		cout << "Enter your password: ";
		cin >> password;

		
		

		bool isValid;
		Password test;
		isValid = test.getpassword(password);

		if (isValid == 1)
		{
			cout << "The password is valid" << endl;
			cout << "TEST POINT HERE" << endl;
			cout << "Confirm password: ";
			cin >> passwordconfirm;
			cout << "TEST passwordconfirm1 : " << passwordconfirm << endl;
			cout << "TEST password : " << password << endl;
			cin.ignore(256, '\n');
			cout << "TEST passwordconfirm2 : " << passwordconfirm << endl;


			int m = 0;
			int k = 0;
			while (file >> user >> pass)
			{
				cout << "TEST user=  " << user << " pass= " << pass << endl;
				m++;
				if (username != user)
					k++;
			}
			if (m == k && password == passwordconfirm)
				uservalid = true;
			else if (m != k)
			{
				cout << "There is already a user with this username." << endl;

			}
			else if (password == passwordconfirm)
			{
				cout << "The passwords match." << endl;
				cout << password << " TEST POINT1 " << passwordconfirm << endl;
			}

			else
			{
				cout << "The passwords given do not match." << endl;
				cout << password << " TEST POINT2 " << passwordconfirm << endl;


			}

			newuser << username << " " << password << endl;;   // need to fix to make binary
			//newuser.write(reinterpret_cast<char*>(&test), sizeof(test));


			file.close();
			newuser.close();
		}

		else
		{
			cout << "The password is invalid" << endl;
		}

	}

}


// **********************************************************

bool Password::userLogin()
{
	string user;
	string pass;

	int loginattempts = 0;
	fstream userfile;
	userfile.open("users.dat", ios::in | ios::binary);
	string userset, passset;
	if (!userfile.is_open())
	{
		cout << "file not found" << endl;
	}
	else
	{
		cout << endl;
		cout << "1. Login " << endl;
		cout << "2. Register New User" << endl;
		cout << "Enter choice '1' or '2' :";
		int option;
		cin >> option;
		cin.ignore(256, '\n');

		if (option == 1)
		{
			while (LoginCheck(user, pass) == 0)
			{
				loginattempts++;
				cout << "Enter Username: ";
				cin >> user;

				//cin.clear;
				cin.ignore(256, '\n');

				cout << "Enter Password: ";
				cin >> pass;

				//cin.clear;
				cin.ignore(256, '\n');
				

				if (LoginCheck(user, pass) != 0)
				{
					cout << "*** Aminstration Program ***" << endl;
					cout << "Welcome " << user << " to the Administration Program." << endl;
					userfile.close();
					return true;
				}
				else if (loginattempts == 3)
				{
					cout << "Maximum login attempts exceeded." << endl;
					break;
				}
				else
				{
					cout << "Invalid username/password combination" << endl;
				}
			}
			userfile.close();
			return false;
		}
		else if (option == 2)
		{
			Register();
			return false;
		}
	}
}