// Version 0.1 wh and dp and zs
// testMainPassword.cpp
// CIT237-01 - Bakery Group Project Test Main Password
// used to test password validation 
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017

#include <iostream>
#include <fstream>
#include <cstdlib>  // For Rand and srand
#include <ctime>    // For the time function
#include <string>
#include <iomanip>

#include "Password.h"
using namespace std;


void displayAdminHomeScreen();

void displayInventory();
void displayCurrency();
void displayAccounting();

void addToCurrency();
void addToInventory();
void maintainFXRates();

int main()
{
	Password admin;
	if (admin.userLogin()) {
		displayAdminHomeScreen();
	}
	system("pause");
	return 0;
}

void displayAdminHomeScreen()
{
	cout << "***** Home Menu Administration *****" << endl;
	cout << "  1) Display Inventory" << endl;
	cout << "  2) Display Currency" << endl;
	cout << "  3) Display Accounting" << endl;
	cout << endl;
	cout << "*****************************************" << endl;
	cout << "  4) Add/modify Currency Cash Register" << endl;
	cout << "  5) Add/Modify Bakery Inventory and Pricing" << endl;
	cout << "  6) Add/Modify FX Rates" << endl;
	cout << endl;
	cout << "*****************************************" << endl;
	cout << "  7) Add/Modify User Name / Password" << endl;
	cout << "  8) Create New User Name and Password" << endl;
	cout << endl;
	cout << "9) Exit System" << endl;
	cout << endl;

	cout << "Enter your choice: ";
	int input;
	cin >> input;
	switch (input) {
	case 1:
		displayInventory();
		break;
	case 2:
		displayCurrency();
		break;
	case 3:
		displayAccounting();
		break;
	case 4:
		addToCurrency();
		break;
	case 5:
		addToInventory();
		break;
	case 6:
		maintainFXRates();
		break;
	case 7:
		cout << "<!> Line 83 stuff is missing <!>" << endl;
		//Modify username and password code here. 
		break;
	case 8:
		cout << "<!> Line 87 stuff is missing <!>" << endl;
		//Create new username and password code here.
		break;
	case 9:
		break;
	default:
		break;
	}



}

void displayInventory() {
	cout << "*******************INVENTORY REPORT*******************\n";
	ifstream dataFile("BakeryItems.txt"); // Open file to read
	if (dataFile.fail())  // If the file was successfully opened, continue
	{
		cout << "Can't open!" << endl;
	}
	else {
		string line;
		while (getline(dataFile, line))
		{
			cout << line << endl;
		}
		dataFile.close();
	}


}

void displayCurrency() {
	cout << "*******************CURRENCY REPORT*******************\n";
	ifstream dataFile("reg.txt"); // Open file to read
	if (dataFile.fail())  // If the file was successfully opened, continue
	{
		cout << "Can't open!" << endl;
	}
	else {
		string line;
		while (getline(dataFile, line))
		{
			cout << line << endl;
		}
		dataFile.close();
	}

}

void displayAccounting() {

}

void addToCurrency() {

}

void addToInventory() {
	//
}

void maintainFXRates() {
	//
}

