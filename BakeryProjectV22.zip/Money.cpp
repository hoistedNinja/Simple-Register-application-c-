#include "Money.h"

// version 0.1

void Money::saveToFile()
{
	ofstream myfile("example.txt");
	if (myfile.is_open())
	{
		myfile << "Balance Amount:" << balanceAmount;
		myfile << "Date Count:" << dateCount;
		myfile << "Base Currency:" << baseCurrency;
		myfile.close();
	}
	else cout << "Unable to open file";
}
