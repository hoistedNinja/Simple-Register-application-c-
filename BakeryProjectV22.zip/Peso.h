// version 0.1 dp
#pragma once
#ifndef Peso
#define Peso
#include "Currency.h"
#include <string>
using namespace std;
class MXN : public Currency {

private:
	double fxrate = 18.5233;
	char mxnSymbol = 'M';
public:
	MXN()
	{

	}
	MXN(string name, string symbol,double value) :Currency(name, symbol,value)
	{

	};
	double getFxRate();
	double convertFromUsd(double);
	double convertToUsd(double);
	char getSymbol() { return mxnSymbol;}

	string toString(double value);
};

#endif // !Mexican Peso
