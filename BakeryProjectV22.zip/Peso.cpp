// version 0.1
#include "Peso.h"


double MXN::getFxRate() {
	return fxrate;
}

double MXN::convertFromUsd(double amt) {
	return amt * fxrate;
}

double MXN::convertToUsd(double amt) {
	return amt / fxrate;
}

string MXN::toString(double value)
{
	ostringstream con, sym;

	con << value;
	sym << mxnSymbol;
	string returnString = sym.str() + " " + " $" + con.str();
	return returnString;
}