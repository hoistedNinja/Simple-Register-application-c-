// Version 0.3 zs and dp
// CreditCard.cpp
// CIT237-01 - Bakery Group Project  - CreditCard
// Will be used to validate the checksum for credit card purchases
// The credit card number will not be stored.
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017

#include "CreditCard.h"

#include <iostream>

// enter the card number
bool CreditCard::setcard() {
	cout << "Enter card number" << endl;
	char a;
	bool returnVal = false;
	int count = 0, intval = 0, case1rval = 0, case2rval = 0;
	while (cin.get(a) && a != '\n')
	{
		if (isdigit(a)) {
			intval = (a - '0');
			case1rval += case1(intval, count);                  //call case1
		    case2rval += case2(intval, count);
			count++;

		}
		
	}
	cout << case1rval << " " << case2rval << endl;
	if (count % 2 != 0) 
		returnVal = validatecardnum(case1rval);
	else 
		returnVal = validatecardnum(case2rval);
	return returnVal;

}
	// clear the stack


	// case one for odd length credit card numbers
	int CreditCard::case1(int value, int count) {                       //case 1, if count is not divisible by 2
		int dnum, sendnum, div, mod, accumulate = 0;
		if (count % 2 != 0) {                                   // for odd number position
			if (value * 2 > 9)
			{
				dnum = value * 2;                                // numbers greater than 9 are split 
				mod = dnum % 10;
				div = dnum / 10;
				accumulate = (mod + div);
			}
			else
			{
				accumulate = value * 2;
			}
		}
		else
		{
			accumulate = value;
		}
		return accumulate;

	
}

int CreditCard::case2(int value, int count) {                                      //if count is divisible by 2
	int dnum, sendnum, div, mod, accumulate = 0;
	if (count % 2 == 0)                                             // for even number position
	{
		if (value * 2>9)
		{
			dnum = value * 2;                                           // numbers greater than 9 are split
			mod = dnum % 10;
			div = dnum / 10;
			accumulate = (mod + div);
		}
		else
		{
			accumulate = value * 2;
		}
	}
	else
	{
		accumulate = value;
	}
	return accumulate;
	

}


bool CreditCard::validatecardnum(int checksum) {                             // validation
	bool check = true;
	if (checksum % 10 == 0)
	{
		cout << "That is a VALID ID number" << endl;
	}
	else
	{
		cout << "**INVALID ID NUMBER**" << endl;
		check = false;
	}
	return check;
}


// the following will be added f characters invalidate a credit card number
/*
bool CreditCard::checkforchars(char a)         // this would be used to check for characters - it is not used based on class instructions
{
if (!isdigit(a))
{
return false;
}
}*/










