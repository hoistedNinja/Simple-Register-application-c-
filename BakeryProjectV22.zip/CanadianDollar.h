// Version 0.1 dp
#pragma once
#ifndef CanadianDollar
#define CanadianDollar
#include "Currency.h"
#include <string>
using namespace std;
class CAD : public Currency {

private:
	double fxrate= 1.28563;
	char cadSymbol = 'C';
public:
	CAD() 
	{

	}
	CAD(string name,string symbol,double value):Currency(name,symbol,value)
	{
	
	};

	double getFxRate();

	double convertFromUsd(double);
	double convertToUsd(double);
	char getSymbol() { return cadSymbol; }

	string toString(double value);
};

#endif // !CanadianDollar
