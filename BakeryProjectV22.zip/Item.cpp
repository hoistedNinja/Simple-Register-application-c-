// version 0.7 dp added dozen unit cost
// version 0.5 dp added grandTotal
// version 0.4 dp 
// Version 0.3 wh  11.27.2017 
// Version 0.2 dp
// Version 0.1 tz
// Item.cpp
// CIT237-01 - Bakery Group Project  - Item


// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/28/2017
// Bakery Set Up by Group 1



#include "Item.h"
#include <string>
#include <iostream>
#include <fstream>


#include <cstdlib>  // For Rand and srand
#include <ctime>    // For the time function

#include <iomanip>



using namespace std;



Item::Item()
{

}

Item::Item(string name, double costPerUnit, double bulkCost, int quantity)
{
	itemName = name;
	unitCost = costPerUnit;
	costPerDozen = bulkCost;
	unitQuantity = quantity;
}


// Mutators setters

void Item::setItemName(string itemName)
{
	this->itemName = itemName;
}

void Item::setUnitCost(double unitCost)
{
	this->unitCost = unitCost;
}

void Item::setCostPerDozen(double costPerDozen)
{
	this->costPerDozen = costPerDozen;
}

void Item::setUnitQuantity(int unitQuantity)
{
	this->unitQuantity = unitQuantity;
}

void Item::setItemID(int itemId)
{
	this->itemId = itemId;
}


// Accessors getters

string Item::getItemName()
{
	return itemName;
}

double Item::getUnitCost() const
{
	return unitCost;
}

double Item::getCostPerDozen()
{
	return costPerDozen;
}

int Item::getCurrentCart(int i) {
	return cart[i];
}
int Item::getUnitQuanity()
{
	return unitQuantity;
}

int Item::getItemID()
{
	return itemId;
}

// ****************************************************************
// Function - getNumberOfItems
//
// ***************************************************************
int Item::getNumberOfItems(ifstream &inputFile)
{
	int count = 0;
	string temp;
	getline(inputFile, temp);
	//inputFile.open(fileName);
	while (!inputFile.eof()) {
		getline(inputFile, temp);
		count++;
	}
	return count;
}

// **************************************************************
// Function loadList
//
// ****************************************************************
void Item::loadList(ifstream &inputFile, Item array[], int numberOfTotalItems, int itemAvail[])
{
	string tempS;
	double tempU, tempB;
	int i, tempQ, id;
	cout << endl;
	cout << "**************************TEAM ONE BAKERY****************************" << endl;
	cout << endl;
	cout << "\t" << "Item" << "\t\t\t" << "Price Each" << "\t" << "Dozen" << "\t" << "Qty Avail" << endl;
	cout << "=====================================================================" << endl;
	getline(inputFile, tempS, '}');
	for (i = 0; i < numberOfTotalItems; i++)
	{
		inputFile >> id;
		inputFile.ignore('\n', ',');
		array[i].setItemID(id);


		getline(inputFile, tempS, ',');

		array[i].setItemName(tempS);

		inputFile >> tempU;

		inputFile.ignore('\n', ',');

		array[i].setUnitCost(tempU);
		inputFile >> tempB;

		inputFile.ignore('\n', ',');

		array[i].setCostPerDozen(tempB);
		inputFile >> tempQ;

		inputFile.ignore('\n', ',');

		array[i].setUnitQuantity(tempQ);
		

		if (itemAvail[i] == 1)
		{
			cout << setw(5) << left;
			cout << id;
			cout << setw(15) << left;
			cout << tempS << "\t\t";
			cout << setw(10) << right << setprecision(2) << fixed;
			cout << tempU << "\t";
			if (tempB != -1)
			{
				cout << tempB << "\t";
			}
			else
			{
				cout << "\t";
			}

			cout << tempQ << endl;


			cout << "---------------------------------------------------------------------" << endl;
		}

		//system("pause");
	}
	placeOrder(array, numberOfTotalItems, itemAvail);
	return;
}



// ****************************************************************
// Function - placeOrder
//
// ***************************************************************

void Item::placeOrder(Item array[], int numberOfTotalItems, int itemAvail[])
{
	int input = 0;
	int buyAmount = 0;
	int i = 0, test = 0;
	bool repeatFlag = true;
	cout << "Test: "  << endl;

	while (repeatFlag) {
		cout << "What item would you like to purchase?" << endl;
		cout << "Type the number of your choice: ";
		cin >> input;
		if (input)

			switch (input) {
			case 1:
				 switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 2:
				 switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 3:
				 switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 4:
				 switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 5:
				switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 6:
				switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 7:
				switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 8:
				switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 9:
				 switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			case 10:
				 switchCaseAction(array, numberOfTotalItems, itemAvail, input);
				break;
			default:
				cout << "Invalid option." << endl;
				break;
			}

		repeatFlag = false;
		cout << "\nWould you like to order another item 'Y' = Yes or 'N' = No?";
		char response;
		cin >> response;
		cin.ignore(256, '\n');
		while (response != 'Y' && response != 'y' &&
			response != 'N' && response != 'n')
		{
			cout << "Please enter 'Y' or 'N': ";
			cin >> response;
			cin.ignore(256, '\n');
		}
		if ((response == 'Y') || (response == 'y')) repeatFlag = true;

	}

	//Code to subtract from stock and calculate prices will go here. The array index for the food is 1 minus the Food ID. (See the showCart function on line 298)

	//For example:
	//To fetch the number of orders of chocolate cookies. 
	//Chocolate Cookie's food ID is 4, so the array element will be 1 less than it, which is 3.
	//cart[3] will return how many cookies the customer ordered. So if the customer ordered 5 cookies, cart[3] will return 5.
	int countCost = 0;
	for (countCost = 0; countCost < 10; countCost++) {
		grandTotal += cart[countCost] * array[countCost].getUnitCost();
	}

	//We can then use operations such as "cart[3]*pricePerCookie" to calculate the total cost of cookies
	// Or "cookiesInStock-cart[3]"  to subtract from stock.
	//dailySales[] array can be used, if necessary, to keep track of daily sales.
}



// ****************************************************************
// Function - switchCaseAction
//
// ***************************************************************

void Item::switchCaseAction(Item array[], int numberOfTotalItems, int itemAvail[], int input)
{
	int buyNum = 0;
	int i = 0;
	for (i = 0; i < numberOfTotalItems; i++) {
		if (array[i].getItemID() == input) {
			if (itemAvail[i] == 1)
			{
				cout << "How many" << array[i].getItemName() << "s would you like? ";
				cin >> buyNum;
				if (buyNum > array[i].getUnitQuanity())
				{
					cout << "Sorry, that's more than we have." << endl;
				}
				else
				{
					cart[(array[i].getItemID()) - 1] = buyNum;
				}
			}
			else {
				cout << "Sorry that's not on the menu right now." << endl;
			}
		}
	}
}


// ****************************************************************
// Function - howMany
//
// ***************************************************************
int Item::howmany()
{
	int input;
	cout << "How many of that item would you like to order? ";
	cin >> input;
	return input;
}


// ****************************************************************
// Function - showCart
//
// ***************************************************************
double Item::showCart(Item array[])
{
	const int SIZE = 10;
	double * itemTotCost = new double[SIZE];

	for (int i = 0; i < 10; i++)
	{
		itemTotCost[i] = 0.0;
	}


	for (int i = 0; i < 10; i++)
	{

		if ((double)cart[i] >= 12 && (array[i].getCostPerDozen() != -1))
		{
			itemTotCost[i] += ((cart[i] / 12) * array[i].getCostPerDozen() + cart[i] % 12 * array[i].getUnitCost());
		}
		else
		{
			itemTotCost[i] += (double)cart[i] * (array[i].getUnitCost());
		}
	}


	cout << "TEST " << itemTotCost[1] << endl;



	double tempShow = 0;
	cout << "Your cart:" << endl;
	cout << setw(10) << right << setprecision(2) << fixed;
	cout << "Donut: \t\t\t\t" << setw(15) << cart[0] << setw(15) << " $" << itemTotCost[0] << endl;
	cout << "Bagel: \t\t\t\t" << setw(15) << cart[1] << setw(15) << " $" << itemTotCost[1] << endl;
	cout << "Bunuelos: \t\t\t" << setw(15) << cart[2] << setw(15) << " $" << itemTotCost[2] << endl;
	cout << "Chocolate Cookie: \t\t" << setw(15) << cart[3] << setw(15) << " $" << itemTotCost[3] << endl;
	cout << "Chocolate Cake: \t\t" << setw(15) << cart[4] << setw(15) << " $" << itemTotCost[4] << endl;
	cout << "Lemon Cake: \t\t\t" << setw(15) << cart[5] << setw(15) << " $" << itemTotCost[5] << endl;
	cout << "Deluxe Cherry Pie: \t\t" << setw(15) << cart[6] << setw(15) << " $" << itemTotCost[6] << endl;
	cout << "Cheese Cake: \t\t\t" << setw(15) << cart[7] << setw(15) << " $" << itemTotCost[7] << endl;
	cout << "Ice Cream: \t\t\t" << setw(15) << cart[8] << setw(15) << " $" << itemTotCost[8] << endl;
	cout << "Coffee: \t\t\t" << setw(15) << cart[9] << setw(15) << " $" << itemTotCost[9] << endl;
	cout << endl;
	cout << "==================================================================" << endl;
	cout << endl;

	for (int i = 0; i < 10; i++)
	{

		if ((double)cart[i] >= 12 && (array[i].getCostPerDozen() != -1))
		{
			tempShow += ((cart[i] / 12) * array[i].getCostPerDozen() + cart[i] % 12 * array[i].getUnitCost());
		}
		else
		{
			tempShow += (double)cart[i] * (array[i].getUnitCost());
		}
	}

	const double TAX = .0405;
	double totalTax;
	double grandTotal;

	totalTax = (tempShow*TAX);
	grandTotal = (tempShow + totalTax);

	cout << setw(15) << right << setprecision(2) << fixed;
	cout << "Item total: " << setw(15) << "\t\t\t\t$" << tempShow << endl;
	cout << endl;
	cout << setw(15) << right << setprecision(2) << fixed;
	cout << "Tax: " << setw(15) << "\t\t\t\t$" << totalTax << endl;
	cout << endl;
	cout << setw(15) << right << setprecision(2) << fixed;
	cout << "Your grand total: " << setw(15) << "\t\t\t\t$" << grandTotal << " USD" << endl;



	cartPtr = cart;


	cout << endl;
	return grandTotal;
}



// ****************************************************************
// Function - clearOrder
//
// ***************************************************************
void Item::clearOrder()
{
	for (int i = 0; i < 10; i++) {
		cart[i] = 0;
	}
}





void Item::denominate(Item current[]) {
	for (int i = 0; i < 10; i++) {
		current[i].setUnitQuantity( current[i].getUnitQuanity()-cart[i]);
	}
}


void Item::getCurrentArray(Item current[]) {
	for (int i = 0; i < 10; i++) {
		cout <<"============================================"<< current[i].getUnitQuanity() << endl;
	}
}


void Item::displayCurrentMenu(Item test[]) {
	//item class cpp
	//there is code reuse here that we can fix shouldnt to bad
	cout << "**************************TEAM ONE BAKERY****************************" << endl;
	cout << endl;
	cout << "\t" << "Item" << "\t\t\t" << "Price Each" << "\t" << "Dozen" << "\t" << "Qty Avail" << endl;
	cout << "=====================================================================" << endl;
	for (int i = 0; i < 10; i++) {
		if (test[i].getUnitQuanity()>1)
		{
			cout << setw(5) << left;
			cout << test[i].getItemID();
			cout << setw(15) << left;
			cout << test[i].getUnitCost() << "\t\t";
			cout << setw(10) << right << setprecision(2) << fixed;
			cout << test[i].getCostPerDozen() << "\t";
			if (test[i].getCostPerDozen() != -1)
			{
				cout << test[i].getCostPerDozen() << "\t";
			}
			else
			{
				cout << "\t";
			}

			cout << test[i].getUnitQuanity() << endl;

			cout << "---------------------------------------------------------------------" << endl;
		}

		//system("pause");
	}
}
