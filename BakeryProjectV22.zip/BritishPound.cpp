// version 0.1 dp
#include "BritishPound.h"


//double BPD::getFxRate() {
double GBP::getFxRate() {
	return fxrate;
}

//double BPD::convertFromUsd(double dollars) {
double GBP::convertFromUsd(double dollars) {
	return dollars * fxrate;
}

//double BPD::convertToUsd(double dollars) {
double GBP::convertToUsd(double dollars) {
	return dollars / fxrate;
}

string GBP::toString(double value)
{
	ostringstream con, sym;

	con << value;
	sym << gbpSymbol;
	string returnString = sym.str() + " " + " $" + con.str();
	return returnString;
}