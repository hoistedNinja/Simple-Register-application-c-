// version 0.1 dp
#include "CanadianDollar.h"


double CAD::getFxRate() {
	return fxrate;
}

double CAD::convertFromUsd(double dollars) {
	return dollars * fxrate;
}

double CAD::convertToUsd(double dollars) {
	return dollars / fxrate;
}

string CAD::toString(double value)
{
	ostringstream con, sym;

	con << value;
	sym << cadSymbol;
	string returnString = sym.str() + " " + " $" + con.str();
	return returnString;
}