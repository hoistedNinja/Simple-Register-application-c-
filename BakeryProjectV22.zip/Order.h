// Version 0.3 added repeatFlag code dp
// Version 0.1 wh
// Order.h
// CIT237-01 - Bakery Group Project  - Order
// used to track orders
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/14/2017


//#include "Item.h"
//#include <string>


#pragma once
#ifndef ORDER_H
#define ORDER_H
#include <iostream>

using namespace std;

class Order {
private:		//These keep track of the number of orders placed on items. These numbers can be passed to other objects, such as the register, to determine total costs.




public:

};

#endif
