// version 0.1
#include "Rupee.h"


double INR::getFxRate() {
	return fxrate;
}
double INR::convertFromUsd(double dollars) {
	return dollars * fxrate;
}
double INR::convertToUsd(double dollars) {
	return dollars / fxrate;
}

string INR::toString(double value)
{
	ostringstream con, sym;

	con << value;
	sym << inrSymbol;
	string returnString = sym.str() + " " + " $" + con.str();
	return returnString;
}