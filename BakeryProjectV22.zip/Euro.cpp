// version 0.1 
#include "Euro.h"


double EUR::getFxRate() {
	return fxrate;
}

double EUR::convertFromUsd(double dollars) {
	return dollars * fxrate;
}

double EUR::convertToUsd(double dollars) {
	return dollars / fxrate;
}



string EUR::toString(double value)
{
	ostringstream con, sym;

	con << value;
	sym << eurSymbol;
	string returnString = sym.str() + " " + " $" + con.str();
	return returnString;
}