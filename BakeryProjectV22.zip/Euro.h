
#pragma once
#ifndef Euro
// version 0.1 dp
#define Euro
#include "Currency.h"
#include <string>
using namespace std;

class EUR : public Currency{

private:
	double fxrate = 0.8432;
	char eurSymbol = 'E';
public:
	EUR()
	{

	}
	EUR(string name, string symbol,double value) :Currency(name, symbol,value)
	{

	};

	double getFxRate();
	double convertFromUsd(double);
	double convertToUsd(double);
	char getSymbol() { return eurSymbol; }
	string toString(double value);
	




	
};

#endif // !CanadianDollar
