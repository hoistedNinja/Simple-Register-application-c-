/* version 0.1 
A Money base class that stores the value, symbol, and name for each coin/bill, and a toString()
method that converts any type money to a string with symbol, formatted amount, and the name of the currency.
The subclasses should allow for overrides for addition and subtraction.

Currency subclasses for each type of money, and a demonstration of the subclassing. Each currency subclass must
have convertToUSD() and convertFromUSD() functions as well as the symbol for the currency.
A print() function that prints the type of money input demonstrating polymorphism.
A toString() function that returns the input amount as a formatted string with the proper currency symbol.

*/


#include "Currency.h"
#include <string>



Currency::Currency()
{
}

Currency::Currency(string  name , string symbol,double value)
{
	currencyName = name;
	currencySymbol = symbol;
	Value = value;
}


string Currency::getCurrencyName() const
{
	return currencyName;
}

string Currency::getCurrencySymbol() const
{
	return currencySymbol;
}

double Currency::getFxRate() 
{
	return 0.0;
}

