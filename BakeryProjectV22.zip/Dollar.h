//Version 0.1 dp
#pragma once
#ifndef Dollar
#define Dollar
#include "Currency.h"
#include <string>
using namespace std;
class USD : public Currency {

private:
	double fxrate = 1.00;
	char usdSymbol = 'U';
public:
	USD()
	{

	}
	USD(string name, string symbol,double value) :Currency(name, symbol,value)
	{

	};

	double getFxRate();
	double convertFromUsd(double dollars);
	double convertToUsd(double dollars);
	char getSymbol() { return usdSymbol; }

	string toString(double value);
};


#endif // !US Dollar
