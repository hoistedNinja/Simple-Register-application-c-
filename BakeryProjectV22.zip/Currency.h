// Version 0.4 dp
// Currency.h
// CIT237-01 - Bakery Group Project  - Currency


// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017



#pragma once
#ifndef CURRENCY_H
#define CURRENCY_H
#include <sstream>
#include <iostream>
using namespace std;


/*
A Money base class that stores the value, symbol, and name for each coin/bill, and a toString()
method that converts any type money to a string with symbol, formatted amount, and the name of the currency.
The subclasses should allow for overrides for addition and subtraction.

Currency subclasses for each type of money, and a demonstration of the subclassing. Each currency subclass must 
have convertToUSD() and convertFromUSD() functions as well as the symbol for the currency.
A print() function that prints the type of money input demonstrating polymorphism.
A toString() function that returns the input amount as a formatted string with the proper currency symbol.

*/




class Currency
{
private:
	string currencyName;    // i.e. US Dollars   Canadian Dollars
	string currencySymbol;  // i.e. USD          CAD
	double Value;          

public:

	Currency();
	Currency(string, string,double);



	static string toString(Currency * moneyType) {

		double value = moneyType->Value;

		ostringstream con;

		con << value;
			
		string returnString=moneyType->currencyName+" "+moneyType->currencySymbol+" $"+con.str() ;

		return returnString;

	};




	string getCurrencyName() const;
	string getCurrencySymbol() const;
	virtual double getFxRate();
	virtual char getSymbol() = 0;


};
#endif
