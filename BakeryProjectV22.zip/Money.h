// Version 0.2 dp
// Money.h
// CIT237-01 - Bakery Group Project  - Money
// The money class will hold the daily bank deposit amounts
// This is the profit for the day above the initial register amount
// Foreign currency is deposited at the fx conversion rate.
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017


#pragma once
#ifndef MONEY_H
#define MONEY_H

#include <iostream>
#include<string>
#include <fstream>
using namespace std;

class Money
{
private:
	double balanceAmount;   // to hold the amount of the deposit
	int dateCount;         // to hold the day count of the deposit
	string baseCurrency;  // to hold the base currency of the balanceAmount

public:
	// Constructors
	Money(double b = 0.0, int d = 0)
	{
		balanceAmount = b;
		dateCount = d;
	}

	// Destructor

	// Mutators - setters


	void setBalanceAmount(double b)
	{
		balanceAmount = b;
	}

	void setDateCount(int d)
	{
		dateCount = d;
	}

	void saveToFile();

	// Accessors - getters


	double getBalanceAmount() const
	{
		return balanceAmount;
	}


	int getDateCount() const
	{
		return dateCount;
	}
	void moneyDeposit()
	{
		cout << "\n";
		cout << "********** Select Denomination For Deposit **********\n";
		cout << "\n";
		cout << "1 Nickel\n";
		cout << "2 Dime\n";
		cout << "3 Quarter\n";
		cout << "4 Dollar\n";
		cout << "5 Five Dollars\n";
		cout << "6 Ten Dollars\n";
		cout << "7 Twenty Dollars\n";

		cout << "\n";
		cout << "-999 To Cancel\n";  // we dont want to shut the machine so -999 lets review TODO
		cout << "\n";
	}

	void paymentMethod(double totalAmt, double minCreditCard)        // admin function
	{
		cout << "\n";
		cout << "********** Select Method For Payment **********\n";
		cout << "\n";
		cout << "1 U.S Dollars (USD)\n";
		cout << "2 Canadian Dollars (CAD)\n";
		cout << "3 Mexican Pesos (MXN)\n";
		cout << "4 EUROS (EUR)\n";
		cout << "5 British Pound (GBP)\n";
		cout << "6 Indian Rupee (INR)\n";
		if (totalAmt > minCreditCard) { cout << "7 Credit Card\n"; }
		
		cout << "\n";
		cout << "-999 To Cancel\n";  // we dont want to shut the machine so -999 lets review TODO
		cout << "\n";
	}
};
#endif

