// version 0.1 dp
#pragma once
#ifndef BritishPound
#define BritishPound
#include "Currency.h"
#include <string>
using namespace std;
class GBP : public Currency {
private:
	double fxrate = 0.74392;
	char gbpSymbol = 'B';
public:
	GBP()
	{

	}
	GBP(string name, string symbol, double value) : Currency(name, symbol, value)
	{

	};

	double getFxRate();
	double GBP::convertFromUsd(double dollars);
	double GBP::convertToUsd(double dollars);

	char getSymbol() { return gbpSymbol; }
	string toString(double value);

};

#endif // !British Pound
