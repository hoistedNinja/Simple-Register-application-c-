// Version 0.3 zs and dp
// CreditCard.h
// Will be used to validate the checksum for credit card purchases
// The credit card number will not be stored.
// CIT237-01 - Bakery Group Project  - CreditCard
// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017


#pragma once
#ifndef CREDITCARD_H
#define CREDITCARD_H

#include <iostream>


//#ifndef  creditcard_h
//#define  creditcard_h


#include <string>

using namespace std;

class CreditCard {
private:
	
	int case1(int, int);
	int case2(int, int);
	bool validatecardnum(int checksum);
public:
	

	//bool checkforchars(char a);
	


	// Mutators - setters
	bool setcard();

	// Accessors - getters
	


};

#endif