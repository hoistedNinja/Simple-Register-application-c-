// version 0.1 dp
#include "Dollar.h"


double USD::getFxRate() {
	return fxrate;
}

double USD::convertFromUsd(double dollars) {
	return dollars * fxrate;
}

double USD::convertToUsd(double dollars) {
	return dollars / fxrate;
}

string USD::toString(double value)
{
	ostringstream con, sym;

	con << value;
	sym << usdSymbol;
	string returnString = sym.str() + " " + " $" + con.str();
	return returnString;
}