// Version 1.9 added credit card limit and alpha rejest on int choice
// Version 1.8 12/4/2017 added fx deteils for other currencies
// Version 1.7 12/3/2017
// version 1.6
// version 1.5 dp
// version 1.4 dp




#include "CanadianDollar.h"
#include "Dollar.h"
#include "Euro.h"
#include "BritishPound.h"
#include "Peso.h"
#include "Rupee.h"

#include <iostream>
#include <fstream>
#include <cstdlib>  // For Rand and srand
#include <ctime>    // For the time function
#include <string>
#include <iomanip>
#include "CreditCard.h"
#include "Currency.h"
#include "Item.h"
#include "Money.h"
#include "Order.h"
//#include "Password.h"
#include "Register.h"

using namespace std;


// ******************************************************************
// Functions randomNumber
//
// **************************************************************

int randomNumber(int min_Num, int max_Num)  // generate the random number function
{
	int randomNumber;

	randomNumber = (rand() % (max_Num - min_Num + 1)) + min_Num; //limit the range of the random number
																 // uncomment the line below for testing to display random number
																 //cout << "test only The random Number is: " << randomNumber << endl;
	return randomNumber;
}


// ******************************************************************
// Functions checkItems
//
// **************************************************************

bool checkItems(Item  test[]) {
	int count = 0;

	for (int i = 0; i < 10; i++) {
		count += test[i].getUnitQuanity();
		cout << test[i].getUnitQuanity() << "---------------------------------------------------------------dfadgasgasdg" << endl;;
	}
	if (count > 0)
		return true;
	else
		return false;
}




// ******************************************************************
// Functions getValue
// This function is used to check for integer input
// 
// 
// **************************************************************
int getValue() {
	int value;
	bool isgood = false;

	do {
		cout << "Enter valid whole number: ";
		if (!(cin >> value)) { // not an integer
			cout << "\n *** OOPS! ***\n";
			cin.clear();            // clear the fail bit
			cin.ignore(256, '\n');  // clear the rest of the line

		}
		else {
			if (cin.peek() != '\n' && cin.peek() != ' ') {   // might be a character, or a decimal, either way, n.g.
				cout << "\n *** OOPS! ***\n";
				cin.clear();            // clear the fail bit
				cin.ignore(256, '\n');  // clear the rest of the line
			}
			else
				isgood = true;
		}
	} while (!isgood);
	return value;
}



// ******************************************************************
// Functions randomReject
// This function is used for random reject of a dollar bill 
// 
// 
// **************************************************************
bool randomReject()        // reject dollar bill random 1 out of 3 
{

	bool rejectFlag = false;
	int rNumber;
	// the 3 below is used to determine how often the dollar is rejected (1 divided by 3)
	rNumber = randomNumber(1, 3); // this calls the random number generator
								  // it limits the range of the random number from 1 to 3
								  //cout << rNumber << " random number\n";
	if (rNumber == 3)   // the dollar is ejected 33% of the time when the random number is 3
	{
		rejectFlag = true;  // sets the reject flag
		cout << "Your paper bill is not accepted - please enter another one or change instead. ";
	}
	return rejectFlag;

}



// ******************************************************************
// Functions print
// This function displays the currency that can be deposited
// 
// 
// **************************************************************
void print(Currency * obj) {
	cout << obj->getCurrencySymbol() << " | " << obj->getCurrencyName()<< endl;
}






int main() {

	double minCreditCard = 19.99;
	Register reg;
	reg.display();



	Currency * currency;

	EUR eur;
	CAD cad;
	MXN mxn;
	INR inr;
	USD usd;
	GBP gbp;

		
	Item myItem;
	//Item * itemPtr;
	Money myMoney;
	Register myRegister;

	double change = 0.0;    //User inputs the change required.
	double totalTab = 0.0;
	double deposit = 0.0;
	
	const int MIN_VALUE = 3;  // min mumber of items to sell
	const int MAX_VALUE = 10;  // maximum number of items to sell

	const int SIZE = 10;

	int itemAvail[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };  // 0 itme not available 1 if available

	int total = 0;                     // Initialize accumulator
	for (int val : itemAvail)
		total += val;

	// Get the system time to set seed for random number
	unsigned seed = (unsigned)time(0);




	// Seed the random number generator.
	srand(seed);

	int rNumber = 0;              // variable used to hold random number
	int rNumberItem = 0;
	rNumber = randomNumber(MIN_VALUE, MAX_VALUE);  // generate the random number

	int total2 = 0;
	while (total2 < rNumber)
	{
		total2 = 0;
		rNumberItem = randomNumber(1, MAX_VALUE);  // generate the random number

		itemAvail[rNumberItem - 1] = 1;

		for (int count = 0; count < SIZE; count++)
			total2 += itemAvail[count];
	}


	Item *list;
	ifstream dataFile("BakeryItems.txt"); // Open file to read
	int numOfTotalItems;
	if (dataFile.fail())  // If the file was successfully opened, continue
	{
		cout << "Can't open!" << endl;
	}

	numOfTotalItems = myItem.getNumberOfItems(dataFile);

	dataFile.close();  // Close file
	dataFile.open("BakeryItems.txt");

	if (dataFile.fail())  // If the file was successfully opened, continue.
	{
		cout << "Can't open!" << endl;
	}

	list = new Item[numOfTotalItems];



	//loadList(dataFile, list, numOfTotalItems);
	myItem.loadList(dataFile, list, numOfTotalItems, itemAvail);
	
	double grandTotal = 0.0;
	double inGBP = 0.0;
	double inEUR = 0.0;
	double inCAD = 0.0;
	double inINR = 0.0;
	double inUSD = 0.0;
	double inMXN = 0.0;

	double paidInCAD = 0.0;	
	double paidInGBP = 0.0;
	double paidInEUR = 0.0;
	double paidInMXN = 0.0;
	double paidInINR = 0.0;
	double paidInUSD = 0.0;

	int input = 0;
	int buyAmount = 0;
	int i = 0;

	bool shopClosed = false;
	int counter = 0;
	bool ccValidFlag = false;

do {


	if (counter > 0) { myItem.displayCurrentMenu(list);
	myItem.placeOrder(list, numOfTotalItems, itemAvail);
	}


	//myItem.getCurrentArray(list);
	grandTotal = myItem.showCart(list);
	
	totalTab = grandTotal;

	inGBP = 0.0;
	inEUR = 0.0;
	inCAD = 0.0;
	inINR = 0.0;
	inUSD = 0.0;
	inMXN = 0.0;
	
	
	
	cout << "Foreign currency amounts" << endl;

	inGBP = gbp.convertFromUsd(totalTab);
	inEUR = eur.convertFromUsd(totalTab);
	inCAD = cad.convertFromUsd(totalTab);
	inINR = inr.convertFromUsd(totalTab);
	inUSD = usd.convertFromUsd(totalTab);
	inMXN = mxn.convertFromUsd(totalTab);


	cout << setw(10) << setprecision(2) << right << fixed;
	//cout << "GBP\tEUR\tCAD\tINR\tUSD\tMXN" << endl;
	cout << "GBP" << "\t" << "EUR" << "\t" << "CAD" << "\t" << "INR" << "\t" << "USD" << "\t" << "MXN" << endl;
	cout << setw(10) << setprecision(2) << right << fixed;
	cout << inGBP << "\t" << inEUR << "\t" << inCAD << "\t" << inINR << "\t" << inUSD << "\t" << inMXN << endl;
	cout << endl;

	
	cout << "Exchange Rates" << endl;
	cout << setw(10) << setprecision(4) << right << fixed;
	cout << "GBP" << "\t" << "EUR" << "\t" << "CAD" << "\t" << "INR" << "\t" << "USD" << "\t" << "MXN" << endl;
	cout << setw(10) << setprecision(4) << right << fixed;
	cout << gbp.getFxRate() << "\t" << eur.getFxRate() << "\t" << cad.getFxRate() << "\t"
		<< inr.getFxRate() << "\t" << usd.getFxRate() << "\t" << mxn.getFxRate() << endl;
	cout << setw(10) << setprecision(2) << right << fixed;

	cout << "***********************************************" << endl;
	cout << "TEST to display registry" << endl;
	reg.display();
	cout << "***********************************************" << endl;

	paidInCAD = 0.0;
	paidInGBP = 0.0;
	paidInEUR = 0.0;
	paidInMXN = 0.0;
	paidInINR = 0.0;
	paidInUSD = 0.0;
	

	myMoney.paymentMethod(totalTab, minCreditCard);//////////////////////////////////////////////////////////////////////////////
	//****************************************************************

	input = 0;
	buyAmount = 0;
	i = 0;

	
	
	cout << endl;
	//cout << "Type the number of your choice: ";
	//cin >> input;
	
	//cin.ignore(256, '\n');


	input = getValue();
	cin.ignore(256, '\n');
	
	
	
	


	if (input)

		switch (input) {
		case 1:
			cout << "1 U.S Dollars (USD)\n";
			cout << "Amount to pay in US Dollars = $" << inUSD << endl;
			currency = &usd;
			deposit = reg.payment(totalTab, currency);
			change = deposit - totalTab;

			break;
		case 2:
			cout << "2 Canadian Dollars (CAD)\n";

			cout << "Amount to pay in Canadian Dollars = CAD " << inCAD << endl;
			cout << endl;
			cout << "How many Candian Dollars will you pay? ";
			
			cin >> paidInCAD;
			inUSD = cad.convertToUsd(paidInCAD);
			cout << "You are paying " << paidInCAD << " in CAD which is " << inUSD << " in USD" << endl;
			cout << endl;
						
			currency = &cad;
			cout << "Please enter the quantity of each denominations for " << paidInCAD << " paid in CAD" << endl;
			deposit = reg.payment(totalTab, currency);
			change = (deposit) - totalTab;
						
			cout << "CHANGE IS " << change << endl;
			
			break;
		case 3:
			cout << "3 Mexican Pesos (MXN)\n";
			cout << "Amount to pay in Mexican Pesos = MXN " << inMXN << endl;
			cout << endl;
			cout << "How many Mexican Pasos will you pay? ";

			cin >> paidInMXN;
			inUSD = mxn.convertToUsd(paidInMXN);
			cout << "You are paying " << paidInMXN << " in MXN which is " << inUSD << " in USD" << endl;
			cout << endl;

			currency = &mxn;
			cout << "Please enter the quantity of each denominations for " << paidInMXN << " paid in MXN" << endl;
			deposit = reg.payment(totalTab, currency);
			change = deposit - totalTab;

			cout << "CHANGE IS " << change << endl;
			
			break;
		case 4: 
			cout << "4 EUROS (EUR)\n";
			cout << "Amount to pay in EUROS = EUR " << inEUR << endl;
			cout << endl;
			cout << "How many EUROs will you pay? ";

			cin >> paidInEUR;
			inUSD = eur.convertToUsd(paidInEUR);
			cout << "You are paying " << paidInEUR << " in EUR which is " << inUSD << " in USD" << endl;
			cout << endl;

			currency = &eur;
			cout << "Please enter the quantity of each denominations for " << paidInEUR << " paid in EUR" << endl;
			deposit = reg.payment(totalTab,currency);
			change = deposit - totalTab;

			cout << "CHANGE IS " << change << endl;
		
			break;
		case 5:
			cout << "5 British Pound (GBP)\n";
			cout << "Amount to pay in British Pounds = GBP " << inGBP << endl;
			cout << endl;
			cout << "How many GBPs will you pay? ";

			cin >> paidInGBP;
			inUSD = gbp.convertToUsd(paidInEUR);
			cout << "You are paying " << paidInGBP << " in GBP which is " << inUSD << " in USD" << endl;
			cout << endl;

			currency = &gbp;
			cout << "Please enter the quantity of each denominations for " << paidInGBP << " paid in GBP" << endl;
			deposit = reg.payment(totalTab, currency);
			change = deposit - totalTab;

			cout << "CHANGE IS " << change << endl;

			break;
		case 6:
			cout << "6 Indian Rupee (INR)\n";
			cout << "Amount to pay in Indian Rupee = INR " << inINR << endl;
			cout << endl;
			cout << "How many INRs will you pay? ";

			cin >> paidInINR;
			inUSD = inr.convertToUsd(paidInINR);
			cout << "You are paying " << paidInINR << " in INR which is " << inUSD << " in USD" << endl;
			cout << endl;

			currency = &inr;
			cout << "Please enter the quantity of each denominations for " << paidInINR << " paid in INR" << endl;
			deposit = reg.payment(totalTab, currency);
			change = deposit - totalTab;

			cout << "CHANGE IS " << change << endl;

			break;
		case 7:
		{
			cout << "7 Credit Card\n";
		bool repeatFlag = false;
		bool isValid = false;
		int checkSum;
		CreditCard test;
		cout << "TEST to set creditcard" << endl;
		do {
			isValid = test.setcard();
		} while (!isValid);
		
		cout << endl;
		cout << "Your card has been charged $" << inUSD << endl;
		cout << endl;

		}
		break;


		default:
			cout << "Invalid option." << endl;

			break;
		}



	//******************************************************
	cout << "REGISTER CONTAINS MONEY BELOW        -------------||||||||||||||||||||||||||||||||||||" << endl;

	reg.display();



	myItem.denominate(list);
	myItem.getCurrentArray(list);

	//Register reg;    //Creating an object named reg from the Register class.

	
					 //cout << "Enter amount to be paid: $";
					 //cin >> totalTab;



	cout << "Your change is: " <<change<< endl;

	double show = 0.0;   //stores the return value for the giveChange function		
	show = reg.giveChange(change);

	cout << endl;
	cout << "$" << show << endl;
	cout << "Done." << endl;

	cout << "***********************************************" << endl;
	cout << "TEST at end to display registry" << endl;
	reg.display();
	cout << "***********************************************" << endl;


	int closeShopOption = reg.closeShop();
	if (closeShopOption == 999)
		shopClosed = true;

	myItem.clearOrder();

	counter++;

	}while (checkItems(list) && !shopClosed);


	myMoney.saveToFile();
	reg.saveToFile();
	system("pause");
	return 0;


}

