// Version 0.3 added fifties dp 11/5/2017
// Version 0.1 wh
// Register.h
// CIT237-01 - Bakery Group Project  - Register


// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017

#pragma once
#ifndef REGISTER_H
#define REGISTER_H
#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include <math.h> /* floor */
#include "Currency.h"
using namespace std;

class Register {
private:
	int pennies=0; //Types of currencies. More can easily be added if we want to account for $2 bills, $100 bills, etc.
	int nickels=0;
	int dimes=0;
	int quarters=0;
	int ones=0;
	int fives=0;
	int tens=0;
	int twenties=0;
	int fifties=0;
	int cadPennies = 0, cadNickels = 0, cadDimes = 0, cadQuarters = 0, cadDollars = 0, cadFives = 0, cadTens = 0, cadTwenties = 0, cadFifties = 0;
	int mxnPennies = 0, mxnNickels = 0, mxnDimes = 0, mxnQuarters = 0, mxnDollars = 0, mxnFives = 0, mxnTens = 0, mxnTwenties = 0, mxnFifties = 0;
	int eurPennies=0, eurNickels=0, eurDimes=0, eurQuarters=0, eurDollars=0, eurFives=0, eurTens=0, eurTwenties=0, eurFifties=0;  // to euros																									  
	int gbpPennies=0, gbpNickels=0, gbpDimes=0, gbpQuarters=0, gbpDollars=0, gbpFives=0, gbpTens=0, gbpTwenties=0, gbpFifties=0;   
	int inrPennies = 0, inrNickels = 0, inrDimes = 0, inrQuarters = 0, inrDollars = 0, inrFives = 0, inrTens = 0, inrTwenties = 0, inrFifties = 0;
public:
	Register();                              // Constructor
	double giveChange(double n);
	double payment(double n, Currency*);
	void display();
	void test(char symbol, int dollarType, int amt);
	bool Register::randomReject();
	int Register::randomNumber(int min_Num, int max_Num);
	int closeShop();
	void saveToFile(); //Writes the current amout of money into the register.
};

#endif



/*


// Destructor

// Mutator
void setPennies(int p) { pennies = p; }
void setNickels(int n) { nickels = n; }
void setDimes(int d) { dimes = d; }
void setQuarters(int q) { quarters = q; }
void setOnes(int o) { ones = o; }
void setFives(int f) { pennies = f; }
void setTens(int t) { tens = t; }
void setTwenties(int tw) { twenties = tw; }

// Accessor
int getPennies() const { return pennies; }
int getNickels() const { return nickels; }
int getDimes() const { return dimes; }
int getQuarters() const { return quarters; }
int getOnes() const { return ones; }
int getFives() const { return pennies; }
int getTens() const { return tens; }
int getTwenties() const { return twenties; }


*/