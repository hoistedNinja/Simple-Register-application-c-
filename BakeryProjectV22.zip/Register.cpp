// Version 0.8 dp added fifties 11/20/2017
// Version 0.7
// Register.cpp
// CIT237-01 - Bakery Group Project  - Register


// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017


#include "Register.h"
#include "Currency.h"

#include <iomanip>


Register::Register() { //CONSTRUCTOR
	pennies = 22; 
	nickels = 21;
	dimes = 20;
	quarters = 10;
	ones = 10;
	fives = 5;
	tens = 4;
	twenties = 3;
	fifties = 0;  

}



double Register::giveChange(double n) {                       //Input the change you must give back to the customer.
															  //cout << n << " at n givechange" << endl;
	n += .005;
	int money = (n * 100); // using integers to correct 0.009999 != 0.01
						   //cout << n << " at n givechange * 100" << endl;
						   //cout << money << " money after n * 100  this is the issue here" << endl;
	double giveBack = 0;
	int fif = 0;
	int tw = 0;
	int te = 0;
	int fi = 0;
	int on = 0;
	int qu = 0;
	int di = 0;
	int ni = 0;
	int pe = 0;


	if (money >= 5000) { //If the change to give is equal to or more than $50 ..
		while (fifties > 0 && money >= 5000) {    //If you have $50s in the register, keep giving it to them until you 1. run out, 2. change does not need anymore $50s
			fifties--;    //Subtract quantity from register.

			giveBack += 5000;         //Customer now has $50

			money -= 5000;    //Therefore you owe him $50 less.
			fif++;
		}
	}            //Repeat steps with lower denominations until change is fulfilled.
	cout << fif << " $50 bills" << endl;



	if (money >= 2000) { //If the change to give is equal to or more than $20 ..
		while (twenties > 0 && money >= 2000) {    //If you have $20s in the register, keep giving it to them until you 1. run out, 2. change does not need anymore $20s
			twenties--;    //Subtract quantity from register.

			giveBack += 2000;        //Customer now has $20

			money -= 2000;           //Therefore you owe him $20 less.
			tw++;
		}
	}            //Repeat steps with lower denominations until change is fulfilled.
	cout << tw << " $20 bills" << endl;


	if (money >= 1000) {
		while (tens > 0 && money >= 1000) {
			tens--;
			giveBack += 1000;
			money -= 1000;
			te++;
		}
	}
		cout << te << " $10 bills" << endl;


	if (money >= 500) {
		while (fives > 0 && money >= 500) {
			fives--;
			giveBack += 500;
			money -= 500;
			fi++;
		}
	}
	cout << fi << " $5 bills" << endl;


	if (money >= 100) {
		while (ones > 0 && money >= 100) {
			ones--;
			giveBack += 100;
			money -= 100;
			on++;
		}
	}
	cout << on << " $1 bills" << endl;


	if (money >= 25) {
		while (quarters > 0 && money >= 25) {
			quarters--;
			giveBack += 25;
			money -= 25;
			qu++;
		}
	}
	cout << qu << " quarters" << endl;


	if (money >= 10) {
		while (dimes > 0 && money >= 10) {
			dimes--;
			giveBack += 10;
			money -= 10;
			di++;
		}
	}
	cout << di << " dimes" << endl;


	if (money >= 5) {
		while (nickels > 0 && money >= 5) {
			nickels--;
			//cout << giveBack << " beforenick" << endl;
			giveBack += 5;
			//cout << giveBack << " nic" << endl;
			money -= 5;
			ni++;
		}
	}
	cout << ni << " nickels" << endl;


	if (money >= 1) {
		while (pennies > 0 && money >= 1) {
			pennies--;
			//cout << giveBack << " beforepenny" << endl;
			giveBack += 1;
			//cout << giveBack << " penny" << endl;
			money -= 1;
			pe++;
		}
	}
	cout << pe << " pennies" << endl;



	//cout << giveBack << " giveback before div by 100" << endl;
	giveBack /= 100;    // Convert  ex: 12345 to 123.45
						//giveBack -= .005;
						//cout << giveBack << " giveback after div by 100" << endl;

	if (money > 0)
	{
		cout << "Money is GT 0 NOT ENOUGH CHANGE in cash register" << endl;
		return ((n - .005) *-1);
	}

	//if (money != 0)
	if (money < 0)
	{
		cout << "money LT 0" << endl;
		cout << "ERROR: UNABLE TO GIVE CHANGE." << endl;    //Show this message if you can't give back change. 
		pennies += pe;
		nickels += ni;
		dimes += di;
		quarters += qu;
		ones += on;
		fives += fi;
		tens += te;
		twenties += tw;
		fifties += fif;
		cout << "You still owe " << endl;
		return ((n - .005) *-1);
	}
	if (money == 0) {
		return giveBack;    //Give back change owed.
	}

	// ask for payment by denomination
}


// ******************************************************************
// Functions randomNumber
//
// **************************************************************

int Register::randomNumber(int min_Num, int max_Num)  // generate the random number function
{
	int randomNumber;

	randomNumber = (rand() % (max_Num - min_Num + 1)) + min_Num; //limit the range of the random number
																 // uncomment the line below for testing to display random number
																 //cout << "test only The random Number is: " << randomNumber << endl;
	return randomNumber;
}



// ******************************************************************
// Functions randomReject
// This function is used for random reject of a dollar bill 
// 
// 
// **************************************************************
bool Register::randomReject()        // reject dollar bill random 1 out of 3 
{

	bool rejectFlag = 0;
	int rNumber;
	// the 3 below is used to determine how often the dollar is rejected (1 divided by 5)
	rNumber = randomNumber(1, 5); // this calls the random number generator
								  // it limits the range of the random number from 1 to 5
								  //cout << rNumber << " random number\n";
	if (rNumber == 3)   // the dollar is ejected 20% of the time when the random number is 3
	{
		rejectFlag = 1;  // sets the reject flag
		cout << "Your paper bill is not accepted - please enter another one or change instead. ";
	}
	return rejectFlag;

}



// ******************************************************************
// Functions payment
// This function is used  
// 
// 
// **************************************************************

double Register::payment(double n, Currency * c)
{
	bool billRejected = 0;
	double money = 0;
	double i = 0;
	short tag = 0;
	cout << "How much will you be paying?" << endl;

	do
	{
		billRejected = 0;
		cout << "How many 50 bills?" << endl;
		cin >> i;
		cin.ignore();

		billRejected = randomReject();
		cout << "TEST show random value+++++++++++++++++++++++++++ " << billRejected << endl;
	} while (billRejected == 1);


	money += (i*50)/(c->getFxRate());
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
		//cout << "You payed /////////////////////////////////" << money / c->getFxRate()  << endl;
		return money;
	}


	do
	{
		billRejected = 0;

	cout << "How many 20 bills?" << endl;
	cin >> i;
	cin.ignore();

	billRejected = randomReject();
	cout << "TEST show random value+++++++++++++++++++++++++++ " << billRejected << endl;
	} while (billRejected == 1);


	money += (i * 20)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
		//cout << "You payed ///////////////////////////////////////" <<  money / c->getFxRate()  << endl;
		return money;
	}


	do
	{
		billRejected = 0;
	cout << endl;
	cout << "How many 10 bills?" << endl;
	cin >> i;
	cin.ignore();

	billRejected = randomReject();
	cout << "TEST show random value+++++++++++++++++++++++++++ " << billRejected << endl;
	} while (billRejected == 1);


	money += (i * 10)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
		//cout << "You payed //////////////////////////////////////////" << money / c->getFxRate()  << endl;
		return money;
	}



	cout << endl;
	cout << "How many 5 bills?" << endl;
	cin >> i;
	cin.ignore();
	money +=(i * 5)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
	//	cout << "You payed ///////////////////////////////////////////////" << money / c->getFxRate()  << endl;
		return money;
	}




	cout << endl;
	cout << "How many 1 bills?" << endl;
	cin >> i;
	cin.ignore();
	money += (i * 1)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
		//cout << "You payed /////////////////////////////////////////" << money / c->getFxRate()  << endl;
		return money;
	}



	cout << endl;
	cout << "How many .25 coins?" << endl;
	cin >> i;
	cin.ignore();
	money += (i * 0.25)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
		//cout << "You payed ////////////////////////////////////////////////" << money / c->getFxRate() << endl;
		return money;
	}



	cout << endl;
	cout << "How many .10 coins?" << endl;
	cin >> i;
	cin.ignore();
	money +=(i * 0.10)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
		//cout << "You payed ////////////////////////////////////////////////" << money / c->getFxRate() << endl;
		return money;
	}



	cout << endl;
	cout << "How many .05 coin?" << endl;
	cin >> i;
	cin.ignore();
	money += (i * 0.05)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;
	if (money >= n) {
	//	cout << "You payed ///////////////////////////////////////////////////" << money / c->getFxRate() << endl;
		return money;
	}



	cout << endl;
	cout << "How many .01 coin?" << endl;
	cin >> i;
	cin.ignore();
	money +=(i * 0.01)/c->getFxRate();
	if(i>0)
	test(c->getSymbol(), tag,i);
	i = 0;
	tag++;

	if (money >= n) {

		//cout << "You payed /////////////////////////////////////////////////////" << money / c->getFxRate() << endl;
		return money;


	}
	else
	{
		cout << "Did not pay enough for purchase " << endl;
	}
	cout << endl;
	
	//cout << "You payed ////////////////////////////////////////////////////////" << money / c->getFxRate()  << endl;
	return money;

}


// ******************************************************************
// Functions display
// This function is used  
// 
// 
// **************************************************************

void Register::display() {    //Display quantities of currencies in the register.
	
	cout << "****************************************************************" << endl;
	cout << "        The cash register contains the following:            " << endl;
	cout << "                                                          	" << endl;
	cout << "****************************************************************" << endl;
	cout ;
	cout << setw(10) << pennies << " pennies" << endl;
	cout << setw(10) << nickels << " nickels" << endl;
	cout << setw(10) << dimes << " dimes" << endl;
	cout << setw(10) << quarters << " quarters" << endl;
	cout << setw(10) << ones << " $1 bills" << endl;
	cout << setw(10) << fives << " $5 bills" << endl;
	cout << setw(10) << tens << " $10 bills" << endl;
	cout << setw(10) << twenties << " $20 bills" << endl;
	cout << setw(10) << fifties << " $50 bills" << endl;

	cout << setw(10) << "\t.01\t.05\t.10\t.25\t1\t5\t10\t20\t50" << endl;
	cout << endl;
	cout << setw(10) << "Euro " << eurPennies << "\t" << eurNickels
		<< " \t " << eurDimes << " \t" << eurQuarters << " \t" << eurDollars << " \t" 
		<< eurFives << " \t" << eurTens << " \t" << eurTwenties << " \t" << eurFifties << endl;
	cout << endl;
	cout << setw(10) << "CAD " << cadPennies << " \t" << cadNickels << " \t" << cadDimes << " \t"
		<< cadQuarters << " \t" << cadDollars << " \t" << cadFives << " \t"         
		<< cadTens << " \t" << cadTwenties << " \t" << cadFifties << endl;
	cout << endl;
	cout << setw(10) << "IRN amt dollars/coins in order f pennies to fifties: " << inrPennies << " " << inrNickels << " " << inrDimes << " "
		<< inrQuarters << " " << inrDollars << " " << inrFives << " "          //testing
		<< inrTens << " " << inrTwenties << " " << inrFifties << endl;
	cout << endl;
	cout << setw(10) << "MXN " << mxnPennies << " " << mxnNickels << " " << mxnDimes << " "
		<< mxnQuarters << " " << mxnDollars << " " << mxnFives << " "          //testing
		<< mxnTens << " " << mxnTwenties << " " << mxnFifties << endl;
	cout << endl;
	cout << "GBP amt dollars/coins in order f pennies to fifties: " << gbpPennies << " " << gbpNickels << " " << gbpDimes << " "
		<< gbpQuarters << " " << gbpDollars << " " << gbpFives << " "          //testing
		<< gbpTens << " " << gbpTwenties << " " << gbpFifties << endl;


}


int Register::closeShop() {
	int closeShop;
	cout << "Cashier control, '999' to close shop, any other number to continue day" << endl;
	cin >> closeShop;
	return closeShop;
}

void Register::saveToFile()
{
	ofstream myfile("reg.txt");
	if (myfile.is_open())
	{
		myfile << "Pennies: " << pennies << endl;
		myfile << "Nickels: " <<nickels << endl;
		myfile << "Dimes: " <<dimes << endl;
		myfile << "Quarters: "<<quarters << endl;
		myfile << "$1 Bills: " <<ones << endl;
		myfile << "$5 Bills: " << fives << endl;
		myfile << "$10 Bills: " << tens << endl;
		myfile << "$20 Bills: " << twenties << endl;
		myfile << "$50 Bills: " << fifties << endl;

		myfile.close();
	}
	else cout << "Unable to open file";
}



void Register::test(char symbol, int tag, int amt ) {

	switch (symbol) {

	case'E':{
		if (tag == 0)
			eurFifties+=amt;
		else if (tag == 1)
			eurTwenties+=amt;
		else if (tag == 2)
			eurTens+=amt;
		else if (tag == 3)
			eurFives+=amt;
		else if (tag == 4)
			eurDollars+=amt;
		else if (tag == 5)
			eurQuarters+=amt;
		else if (tag == 6)
			eurDimes+=amt;
		else if (tag == 7)
			eurNickels+=amt;
		else
			eurPennies+=amt;

	}
			break;
	case'C': {
		if (tag == 0)
			cadFifties+=amt;
		else if (tag == 1)
			cadTwenties+=amt;
		else if (tag == 2)
			cadTens+=amt;
		else if (tag == 3)
			cadFives+=amt;
		else if (tag == 4)
			cadDollars+=amt;
		else if (tag == 5)
			cadQuarters+=amt;
		else if (tag == 6)
			cadDimes+=amt;
		else if (tag == 7)
			cadNickels+=amt;
		else
			cadPennies+=amt;

	}
			 break;
			
	case'I':{
		if (tag == 0)
			inrFifties+=amt;
		else if (tag == 1)
			inrTwenties+=amt;
		else if (tag == 2)
			inrTens+=amt;
		else if (tag == 3)
			inrFives+=amt;
		else if (tag == 4)
			inrDollars+=amt;
		else if (tag == 5)
			inrQuarters+=amt;
		else if (tag == 6)
			inrDimes+=amt;
		else if (tag == 7)
			inrNickels+=amt;
		else
			inrPennies+=amt;
	}
	         break;
	case'M':{
		if (tag == 0)
			mxnFifties+=amt;
		else if (tag == 1)
			mxnTwenties+=amt;
		else if (tag == 2)
			mxnTens+=amt;
		else if (tag == 3)
			mxnFives+=amt;
		else if (tag == 4)
			mxnDollars+=amt;
		else if (tag == 5)
			mxnQuarters+=amt;
		else if (tag == 6)
			mxnDimes+=amt;
		else if (tag == 7)
			mxnNickels+=amt;
		else
			mxnPennies+=amt;
	}
			break;
	case'B': {
		if (tag == 0)
			gbpFifties+=amt;
		else if (tag == 1)
			gbpTwenties+=amt;
		else if (tag == 2)
			gbpTens+=amt;
		else if (tag == 3)
			gbpFives+=amt;
		else if (tag == 4)
			gbpDollars+=amt;
		else if (tag == 5)
			gbpQuarters+=amt;
		else if (tag == 6)
			gbpDimes+=amt;
		else if (tag == 7)
			gbpNickels+=amt;
		else
			gbpPennies+=amt;
	}
			 break;
	case'U':{
		if (tag == 0)
			fifties+=amt;
		else if (tag == 1)
			twenties+=amt;
		else if (tag == 2)
			tens+=amt;
		else if (tag == 3)
			fives+=amt;
		else if (tag == 4)
			ones+=amt;
		else if (tag == 5)
			quarters+=amt;
		else if (tag == 6)
			dimes+=amt;
		else if (tag == 7)
			nickels+=amt;
		else
			pennies+=amt;
	}
			break;
	default: {
		exit(EXIT_FAILURE);
	}

	}

}





/*

// makingChange.cpp
// CIT-237-01
// Create a program that distributes change using the highest denomination in the cah register.
// The cash register must start with $140.77 in change.
// The cash register must start with three $20 bills.
// The cash register must start with four $10 bills.
// The cash register must start with five $5 bills.
// The cash register must start with ten $1 bills.
// The cash register must start with ten quarters.
// The cash register must start with twenty dimes.
// The cash register must start with 21 nickels.
// The cash register must start with 22 pennies.
// Team 1 - Wilson Ho, David Plantamura, Mahesh Wosti, Zacharia Sabri, Telma Zelaya
// 10/19/2017


Group 1 Project #6
version .1 10/18/2017 - wh
version .2 10/18/2017 added repeat choice - dp
version .3 10/18/2017 added functions that add bills to register and takes into consideration when returning change - wh
Added a way that will ask the customer how they will be paying. The customer's inputs/bills will be added to the register
as they pay. The program will stop asking the user for inputs when it receives enough payment for the item.
The change function will now take in consideration the user's input.
The change function also now returns the bills given if it's not possible to complete the change
version .4 10/19/2017 added cout for error check dp
version .5 10/19/2017 added line 47 - .005 amount dp
version .6 10/19/2017 added line 47 - .005 amount sub out on change to offset line above dp

Use the display function (In the case of this file, use reg.display() )
To display the contents of the cash register.

*/


