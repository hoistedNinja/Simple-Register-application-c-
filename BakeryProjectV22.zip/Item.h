// version 0.1 dp
#pragma once
// Version 0.2
// Item.h
// CIT237-01 - Bakery Group Project  - Item


// Team 1 - Zach,David,Mahesh,Wilson,Telma
// 11/5/2017


// Version 11.27.2017   
// 6:56PM
// Wilson 



#pragma once
#ifndef ITEM_H
#define ITEM_H

#include <string>
#include <iostream>
#include <fstream>
#include "Order.h"

using namespace std;

class Item
{
private:
	string itemName = "";
	int itemId = 0;
	double unitCost = 0;
	double costPerDozen = 0;
	int unitQuantity = 0;
	 int * cartPtr;
	int cart[10] = { 0,0,0,0,0,0,0,0,0,0 }; //For keeping track of the cart.
	int dailySales[10] = { 0,0,0,0,0,0,0,0,0,0 }; //For keeping track of total number of items sold per day.
	double grandTotal = 0;


	int numberOrdered = 0;

   void switchCaseAction(Item array[], int numberOfTotalItems, int itemAvail[], int input);

	int howmany();	//Private function for the switch case. 


public:
	Item();
	Item(string, double, double, int);

	
	void setItemID(int);
	void setItemName(string itemName);
	void setUnitCost(double unitCost);
	void setCostPerDozen(double costPerDozen);
	void setUnitQuantity(int);
	//void setUnitQuantity(int);
	//void switchCaseAction(Item array[], int numberOfTotalItems, int itemAvail[], int input);
	int getItemID();
	string getItemName();
	double getUnitCost() const;
	double getCostPerDozen();
	int getUnitQuanity();
	void getCurrentArray(Item[]);
	int getCurrentCart(int i);
	int getNumberOfItems(ifstream &inputFile);
	void loadList(ifstream &inputFile, Item array[], int numberOfTotalItems, int itemAvail[]);
	void denominate(Item[]);

	/////////////////////////////////////////////////
	void placeOrder(Item array[], int numberOfTotalItems, int itemAvail[]);	//Function to ask the user how many of each item they want.
	double showCart(Item array[]);	//Prints the current cart. Shows all the private int values.
	void clearOrder();	//Sets all the private ints to 0.
						//Returns values for individual items.

	void Item::displayCurrentMenu(Item test[]);

};
#endif





